package tareaPackage;

import java.util.Scanner;

public class segundaTareaClass {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese un precio");
        double precioIngresado = scanner.nextDouble();

        System.out.println("El precio con IVA incluido es: " + precioConIva(precioIngresado));

    }
    public static double precioConIva(double precio){
        double precioFinal = precio + (precio/100*21);
        return precioFinal;
    }
}
