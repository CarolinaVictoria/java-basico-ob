package tareaPackage;

public class primerTareaClass {
    public static void main(String[] args) {
        int datoEntero = 25;
        long datoLong = 2047483647;
        double datoDouble = 5.6;
        boolean datoBoolean = false;
        String datoString = "Hello World";

        System.out.println("Entero = " + datoEntero + " " +
                "Long = " + datoLong + " " +
                "Double = " + datoDouble + " " +
                "Boolean = " + datoBoolean + " " +
                "String = " + datoString);
    }
}
