package tareaPackage;

import java.util.Scanner;

public class terceraTareaClass {
    public static void main(String[] args) {
        String[] nombres = {"Martina", "Josefina", "Lucrecia", "Candela", "Roberta"};

        System.out.println(concatenarTexto(nombres));
    }
    public static String concatenarTexto(String[] unArray){
        String cadena = " ";
        for (int i = 0; i < unArray.length; i++){
            cadena += unArray[i] + ", ";
        }
        return cadena;
    }
}
